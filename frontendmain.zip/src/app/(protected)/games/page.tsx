import GamesPage from "@/modules/games/games";

export default function Page() {
  return <GamesPage />;
}
