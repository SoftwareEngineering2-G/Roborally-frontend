"use client";
import type React from "react";
import { useEffect } from "react";
import { redirect } from "next/navigation";

export default function Layout({ children }: { children: React.ReactNode }) {
  // Check authentication status in useEffect to avoid hydration mismatch
  useEffect(() => {
    const username = localStorage.getItem("username");
    if (username) {
      redirect("/");
    }
  }, []);

  return <>{children}</>;
}
