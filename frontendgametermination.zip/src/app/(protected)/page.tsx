"use client";

import  Home  from "@/modules/home/home";

export default function Page() {
  return <Home />;
}
