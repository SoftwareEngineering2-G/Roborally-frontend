"use client";
import { SignIn } from "@/modules/Signin/sign-in";

const Page = () => {
  return <SignIn />;
};

export default Page;
