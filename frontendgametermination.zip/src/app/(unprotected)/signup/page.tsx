"use client";
import { Signup } from "@/modules/Signup/sign-up";

const Page = () => {
  return <Signup />;
};

export default Page;
