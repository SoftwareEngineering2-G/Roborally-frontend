"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy, Check, X, Play } from "lucide-react";
import { BoardSelector } from "@/components/lobby/BoardSelector";

interface Player {
  username: string;
  isReady: boolean;
}

interface GameControlsProps {
  isHost: boolean;
  currentPlayerReady: boolean;
  players: Player[];
  canStart: boolean;
  allPlayersReady: boolean;
  isPrivate: boolean;
  gameId: string;
  selectedBoard: string;
  onBoardChange: (board: string) => void;
  isPausedGame?: boolean;
  missingPlayers?: string[];
  onToggleReady?: () => void; // Optional since player ready is not supported yet
  onStartGame: () => void;
  onContinueGame: () => void;
  onCopyGameId: () => void;
}

export const GameControls = ({
  isHost,
  currentPlayerReady,
  players,
  canStart,
  allPlayersReady,
  isPrivate,
  gameId,
  selectedBoard,
  onBoardChange,
  isPausedGame = false,
  missingPlayers = [],
  onToggleReady,
  onStartGame,
  onContinueGame,
  onCopyGameId,
}: GameControlsProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{isHost ? "Host Controls" : "Player Status"}</CardTitle>
          <CardDescription>
            {isHost ? "Configure and start the game" : "Get ready to play"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!isHost && onToggleReady && (
            <Button
              onClick={onToggleReady}
              variant={currentPlayerReady ? "destructive" : "default"}
              className="w-full"
            >
              {currentPlayerReady ? (
                <>
                  <X className="w-4 h-4 mr-2" />
                  Cancel Ready
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Ready Up
                </>
              )}
            </Button>
          )}

          {isHost && (
            <>
              <BoardSelector
                value={selectedBoard}
                onValueChange={onBoardChange}
                disabled={isPausedGame}
              />

              <div className="pt-2 space-y-3">
                <Button
                  onClick={isPausedGame ? onContinueGame : onStartGame}
                  disabled={!canStart || !selectedBoard}
                  className="w-full h-12 text-base font-semibold"
                  size="lg"
                >
                  <Play className="w-5 h-5 mr-2" />
                  {selectedBoard
                    ? isPausedGame
                      ? `Continue Game on ${selectedBoard}`
                      : `Start Game on ${selectedBoard}`
                    : "Select a Board to Start"}
                </Button>

                {isPausedGame && missingPlayers.length > 0 && (
                  <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                    <p className="text-sm text-yellow-600 dark:text-yellow-400 font-semibold mb-1">
                      Waiting for required players:
                    </p>
                    <p className="text-xs text-yellow-600/80 dark:text-yellow-400/80">
                      {missingPlayers.join(", ")}
                    </p>
                  </div>
                )}

                {!isPausedGame && !allPlayersReady && players.length >= 2 && (
                  <div className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/20 p-2 rounded">
                    <span className="text-lg">⏳</span>
                    <span>Waiting for all players to be ready</span>
                  </div>
                )}

                {!isPausedGame && players.length < 2 && (
                  <div className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/20 p-2 rounded">
                    <span className="text-lg">👥</span>
                    <span>Need at least 2 players to start</span>
                  </div>
                )}
              </div>
            </>
          )}

          {isPrivate && (
            <div className="pt-4 border-t">
              <p className="text-sm text-muted-foreground mb-2">Lobby Key:</p>
              <div className="flex items-center space-x-2">
                <code className="flex-1 p-2 bg-muted rounded text-primary font-mono text-sm">
                  {gameId}
                </code>
                <Button size="sm" variant="outline" onClick={onCopyGameId}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};
