export interface GameBoard {
  name: string;
}
